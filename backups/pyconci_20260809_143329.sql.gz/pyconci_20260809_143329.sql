--
-- PostgreSQL database dump
--

\restrict jhxMc484mFkBmTH2vseLYcCF5YSEiAWG0MzYBthjI2fbJmCXvAz9LHxkaposfis

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg13+1)
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: articlestatus; Type: TYPE; Schema: public; Owner: pycon_admin
--

CREATE TYPE public.articlestatus AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.articlestatus OWNER TO pycon_admin;

--
-- Name: orderstatus; Type: TYPE; Schema: public; Owner: pycon_admin
--

CREATE TYPE public.orderstatus AS ENUM (
    'pending',
    'paid',
    'failed',
    'cancelled'
);


ALTER TYPE public.orderstatus OWNER TO pycon_admin;

--
-- Name: paymentmethod; Type: TYPE; Schema: public; Owner: pycon_admin
--

CREATE TYPE public.paymentmethod AS ENUM (
    'card',
    'mobile_money',
    'unknown'
);


ALTER TYPE public.paymentmethod OWNER TO pycon_admin;

--
-- Name: paymentstatus; Type: TYPE; Schema: public; Owner: pycon_admin
--

CREATE TYPE public.paymentstatus AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed',
    'cancelled',
    'refunded'
);


ALTER TYPE public.paymentstatus OWNER TO pycon_admin;

--
-- Name: reportstatus; Type: TYPE; Schema: public; Owner: pycon_admin
--

CREATE TYPE public.reportstatus AS ENUM (
    'new',
    'in_review',
    'resolved',
    'dismissed'
);


ALTER TYPE public.reportstatus OWNER TO pycon_admin;

--
-- Name: submissionformat; Type: TYPE; Schema: public; Owner: pycon_admin
--

CREATE TYPE public.submissionformat AS ENUM (
    'talk',
    'workshop'
);


ALTER TYPE public.submissionformat OWNER TO pycon_admin;

--
-- Name: submissionstatus; Type: TYPE; Schema: public; Owner: pycon_admin
--

CREATE TYPE public.submissionstatus AS ENUM (
    'submitted',
    'in_review',
    'accepted',
    'rejected'
);


ALTER TYPE public.submissionstatus OWNER TO pycon_admin;

--
-- Name: ticketstatus; Type: TYPE; Schema: public; Owner: pycon_admin
--

CREATE TYPE public.ticketstatus AS ENUM (
    'valid',
    'used',
    'cancelled'
);


ALTER TYPE public.ticketstatus OWNER TO pycon_admin;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: pycon_admin
--

CREATE TYPE public.userrole AS ENUM (
    'admin',
    'moderator',
    'staff',
    'participant'
);


ALTER TYPE public.userrole OWNER TO pycon_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO pycon_admin;

--
-- Name: articles; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.articles (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    content text NOT NULL,
    excerpt character varying(500),
    cover_image_url character varying(500),
    meta_title character varying(255),
    meta_description character varying(300),
    status public.articlestatus NOT NULL,
    author_id integer,
    published_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.articles OWNER TO pycon_admin;

--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.articles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_id_seq OWNER TO pycon_admin;

--
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.articles_id_seq OWNED BY public.articles.id;


--
-- Name: cfp_submissions; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.cfp_submissions (
    id integer NOT NULL,
    speaker_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    topic character varying(120) NOT NULL,
    level character varying(80) NOT NULL,
    format public.submissionformat NOT NULL,
    status public.submissionstatus NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.cfp_submissions OWNER TO pycon_admin;

--
-- Name: cfp_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.cfp_submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cfp_submissions_id_seq OWNER TO pycon_admin;

--
-- Name: cfp_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.cfp_submissions_id_seq OWNED BY public.cfp_submissions.id;


--
-- Name: conduct_reports; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.conduct_reports (
    id integer NOT NULL,
    description text NOT NULL,
    contact_email character varying(255),
    incident_location character varying(255),
    status public.reportstatus NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.conduct_reports OWNER TO pycon_admin;

--
-- Name: conduct_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.conduct_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.conduct_reports_id_seq OWNER TO pycon_admin;

--
-- Name: conduct_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.conduct_reports_id_seq OWNED BY public.conduct_reports.id;


--
-- Name: niveaux_sponsor; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.niveaux_sponsor (
    id integer NOT NULL,
    nom character varying(50) NOT NULL,
    ordre_affichage integer NOT NULL,
    couleur character varying(7)
);


ALTER TABLE public.niveaux_sponsor OWNER TO pycon_admin;

--
-- Name: niveaux_sponsor_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.niveaux_sponsor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.niveaux_sponsor_id_seq OWNER TO pycon_admin;

--
-- Name: niveaux_sponsor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.niveaux_sponsor_id_seq OWNED BY public.niveaux_sponsor.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    user_id integer,
    customer_name character varying(255) NOT NULL,
    customer_email character varying(255) NOT NULL,
    customer_phone character varying(32) NOT NULL,
    ticket_category_id integer NOT NULL,
    quantity integer NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    status public.orderstatus NOT NULL,
    payment_reference character varying(255),
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.orders OWNER TO pycon_admin;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO pycon_admin;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    order_id integer NOT NULL,
    geniuspay_id character varying(255) NOT NULL,
    geniuspay_reference character varying(255) NOT NULL,
    amount numeric(12,2) NOT NULL,
    fee numeric(12,2),
    net_amount numeric(12,2),
    status public.paymentstatus NOT NULL,
    method public.paymentmethod NOT NULL,
    environment character varying(50) NOT NULL,
    raw_webhook_payload text,
    created_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone
);


ALTER TABLE public.payments OWNER TO pycon_admin;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO pycon_admin;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.rooms (
    id integer NOT NULL,
    name character varying(120) NOT NULL,
    capacity integer NOT NULL
);


ALTER TABLE public.rooms OWNER TO pycon_admin;

--
-- Name: rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.rooms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rooms_id_seq OWNER TO pycon_admin;

--
-- Name: rooms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.rooms_id_seq OWNED BY public.rooms.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description character varying(1200),
    room_id integer NOT NULL,
    start_at timestamp with time zone NOT NULL,
    end_at timestamp with time zone NOT NULL,
    topic character varying(120),
    level character varying(80),
    speaker_id integer
);


ALTER TABLE public.sessions OWNER TO pycon_admin;

--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sessions_id_seq OWNER TO pycon_admin;

--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: speakers; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.speakers (
    id integer NOT NULL,
    user_id integer,
    name character varying(255) NOT NULL,
    bio text,
    photo_url character varying(500),
    social_links text
);


ALTER TABLE public.speakers OWNER TO pycon_admin;

--
-- Name: speakers_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.speakers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.speakers_id_seq OWNER TO pycon_admin;

--
-- Name: speakers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.speakers_id_seq OWNED BY public.speakers.id;


--
-- Name: sponsors; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.sponsors (
    id integer NOT NULL,
    nom character varying(150) NOT NULL,
    logo_url character varying(500) NOT NULL,
    lien_site character varying(500) NOT NULL,
    niveau_id integer NOT NULL
);


ALTER TABLE public.sponsors OWNER TO pycon_admin;

--
-- Name: sponsors_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.sponsors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sponsors_id_seq OWNER TO pycon_admin;

--
-- Name: sponsors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.sponsors_id_seq OWNED BY public.sponsors.id;


--
-- Name: ticket_categories; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.ticket_categories (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    price numeric(10,2) NOT NULL,
    currency character varying(3) NOT NULL,
    quota integer NOT NULL,
    sale_start date,
    sale_end date
);


ALTER TABLE public.ticket_categories OWNER TO pycon_admin;

--
-- Name: ticket_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.ticket_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_categories_id_seq OWNER TO pycon_admin;

--
-- Name: ticket_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.ticket_categories_id_seq OWNED BY public.ticket_categories.id;


--
-- Name: tickets; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.tickets (
    id integer NOT NULL,
    order_id integer NOT NULL,
    qr_code character varying(255) NOT NULL,
    status public.ticketstatus NOT NULL,
    issued_at timestamp with time zone NOT NULL,
    note text
);


ALTER TABLE public.tickets OWNER TO pycon_admin;

--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tickets_id_seq OWNER TO pycon_admin;

--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.tickets_id_seq OWNED BY public.tickets.id;


--
-- Name: translations; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.translations (
    id integer NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id integer NOT NULL,
    language character varying(5) NOT NULL,
    field character varying(50) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.translations OWNER TO pycon_admin;

--
-- Name: translations_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.translations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.translations_id_seq OWNER TO pycon_admin;

--
-- Name: translations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.translations_id_seq OWNED BY public.translations.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: pycon_admin
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(255),
    hashed_password character varying(255) NOT NULL,
    role public.userrole NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.users OWNER TO pycon_admin;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: pycon_admin
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO pycon_admin;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pycon_admin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.articles ALTER COLUMN id SET DEFAULT nextval('public.articles_id_seq'::regclass);


--
-- Name: cfp_submissions id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.cfp_submissions ALTER COLUMN id SET DEFAULT nextval('public.cfp_submissions_id_seq'::regclass);


--
-- Name: conduct_reports id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.conduct_reports ALTER COLUMN id SET DEFAULT nextval('public.conduct_reports_id_seq'::regclass);


--
-- Name: niveaux_sponsor id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.niveaux_sponsor ALTER COLUMN id SET DEFAULT nextval('public.niveaux_sponsor_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: rooms id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.rooms ALTER COLUMN id SET DEFAULT nextval('public.rooms_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: speakers id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.speakers ALTER COLUMN id SET DEFAULT nextval('public.speakers_id_seq'::regclass);


--
-- Name: sponsors id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.sponsors ALTER COLUMN id SET DEFAULT nextval('public.sponsors_id_seq'::regclass);


--
-- Name: ticket_categories id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.ticket_categories ALTER COLUMN id SET DEFAULT nextval('public.ticket_categories_id_seq'::regclass);


--
-- Name: tickets id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.tickets ALTER COLUMN id SET DEFAULT nextval('public.tickets_id_seq'::regclass);


--
-- Name: translations id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.translations ALTER COLUMN id SET DEFAULT nextval('public.translations_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.alembic_version (version_num) FROM stdin;
b68c9e2953a4
\.


--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.articles (id, title, slug, content, excerpt, cover_image_url, meta_title, meta_description, status, author_id, published_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cfp_submissions; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.cfp_submissions (id, speaker_id, title, description, topic, level, format, status, created_at) FROM stdin;
1	1	Introduction à FastAPI pour les développeurs Django	Ce talk présente les concepts clés de FastAPI (routing, validation Pydantic, async) en les comparant directement aux équivalents Django, pour faciliter la transition des développeurs déjà familiers avec Django.	Backend	Débutant	talk	accepted	2026-08-08 17:21:51.143677+00
\.


--
-- Data for Name: conduct_reports; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.conduct_reports (id, description, contact_email, incident_location, status, created_at) FROM stdin;
1	Test de signalement pour vérifier le formulaire.	temoin@example.com	Salle B, pause déjeuner	new	2026-08-08 13:16:09.02461+00
2	Test de signalement pour vérifier le formulaire.	temoin@example.com	Salle B, pause déjeuner	new	2026-08-08 14:03:49.126512+00
3	Test de signalement pour vérifier le formulaire.	temoin@example.com	Salle B, pause déjeuner	new	2026-08-08 14:18:39.777506+00
4	Test de limite de débit	\N	\N	new	2026-08-09 14:03:10.183545+00
5	Test de limite de débit	\N	\N	new	2026-08-09 14:03:17.483468+00
6	Test de limite de débit	\N	\N	new	2026-08-09 14:03:20.08055+00
\.


--
-- Data for Name: niveaux_sponsor; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.niveaux_sponsor (id, nom, ordre_affichage, couleur) FROM stdin;
1	Or	1	#FFD700
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.orders (id, user_id, customer_name, customer_email, customer_phone, ticket_category_id, quantity, total_amount, status, payment_reference, created_at) FROM stdin;
1	1	Diarrassouba Mohamed Aliou	dma@momo.com	+225 01 01 43 87 43	1	1	15000.00	paid	\N	2026-08-08 21:10:14.212236+00
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.payments (id, order_id, geniuspay_id, geniuspay_reference, amount, fee, net_amount, status, method, environment, raw_webhook_payload, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.rooms (id, name, capacity) FROM stdin;
1	Amphithéâtre A	150
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.sessions (id, title, description, room_id, start_at, end_at, topic, level, speaker_id) FROM stdin;
\.


--
-- Data for Name: speakers; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.speakers (id, user_id, name, bio, photo_url, social_links) FROM stdin;
1	\N	Jane Doe	Développeuse Python	\N	twitter.com/jane
\.


--
-- Data for Name: sponsors; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.sponsors (id, nom, logo_url, lien_site, niveau_id) FROM stdin;
1	Acme Corp	https://media.istockphoto.com/id/2179583104/photo/youtube-gold-icon-element-on-white-background.webp?s=1024x1024&w=is&k=20&c=kKD_4qMzCi7meXN9Q4ypuz5qMpiA4nKCElxMXIf0Ay8=	https://www.youtube.com/	1
2	Acme Corp	https://exemple.com/logo.png	https://acme.com	1
3	Acme Corp	https://media.istockphoto.com/id/2179583104/photo/youtube-gold-icon-element-on-white-background.webp?s=1024x1024&w=is&k=20&c=kKD_4qMzCi7meXN9Q4ypuz5qMpiA4nKCElxMXIf0Ay8=	https://www.youtube.com/	1
\.


--
-- Data for Name: ticket_categories; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.ticket_categories (id, name, price, currency, quota, sale_start, sale_end) FROM stdin;
1	Standard	15000.00	XOF	99	2026-08-08	2026-08-08
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.tickets (id, order_id, qr_code, status, issued_at, note) FROM stdin;
1	1	TEST-QR-0001	valid	2026-08-08 21:16:02.502937+00	\N
\.


--
-- Data for Name: translations; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.translations (id, entity_type, entity_id, language, field, value) FROM stdin;
1	article	1	en	title	Welcome to the PyCon CI blog
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: pycon_admin
--

COPY public.users (id, email, full_name, hashed_password, role, is_active, created_at) FROM stdin;
1	admin@pyconci.ci	Mohamed	$2b$12$gkK5ZmLUetA7.VaODcr7fuqwNBJV6x8uGLDK5ui04CrZxJjmtRRrG	admin	t	2026-08-07 01:16:56.413714+00
\.


--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.articles_id_seq', 1, true);


--
-- Name: cfp_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.cfp_submissions_id_seq', 1, true);


--
-- Name: conduct_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.conduct_reports_id_seq', 6, true);


--
-- Name: niveaux_sponsor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.niveaux_sponsor_id_seq', 1, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.rooms_id_seq', 1, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.sessions_id_seq', 1, false);


--
-- Name: speakers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.speakers_id_seq', 1, true);


--
-- Name: sponsors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.sponsors_id_seq', 3, true);


--
-- Name: ticket_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.ticket_categories_id_seq', 1, true);


--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.tickets_id_seq', 1, true);


--
-- Name: translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.translations_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pycon_admin
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: cfp_submissions cfp_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.cfp_submissions
    ADD CONSTRAINT cfp_submissions_pkey PRIMARY KEY (id);


--
-- Name: conduct_reports conduct_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.conduct_reports
    ADD CONSTRAINT conduct_reports_pkey PRIMARY KEY (id);


--
-- Name: niveaux_sponsor niveaux_sponsor_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.niveaux_sponsor
    ADD CONSTRAINT niveaux_sponsor_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_name_key; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_name_key UNIQUE (name);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: speakers speakers_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.speakers
    ADD CONSTRAINT speakers_pkey PRIMARY KEY (id);


--
-- Name: speakers speakers_user_id_key; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.speakers
    ADD CONSTRAINT speakers_user_id_key UNIQUE (user_id);


--
-- Name: sponsors sponsors_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.sponsors
    ADD CONSTRAINT sponsors_pkey PRIMARY KEY (id);


--
-- Name: ticket_categories ticket_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.ticket_categories
    ADD CONSTRAINT ticket_categories_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: translations translations_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.translations
    ADD CONSTRAINT translations_pkey PRIMARY KEY (id);


--
-- Name: translations uq_translation; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.translations
    ADD CONSTRAINT uq_translation UNIQUE (entity_type, entity_id, language, field);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_articles_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_articles_id ON public.articles USING btree (id);


--
-- Name: ix_articles_slug; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE UNIQUE INDEX ix_articles_slug ON public.articles USING btree (slug);


--
-- Name: ix_cfp_submissions_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_cfp_submissions_id ON public.cfp_submissions USING btree (id);


--
-- Name: ix_cfp_submissions_speaker_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_cfp_submissions_speaker_id ON public.cfp_submissions USING btree (speaker_id);


--
-- Name: ix_conduct_reports_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_conduct_reports_id ON public.conduct_reports USING btree (id);


--
-- Name: ix_niveaux_sponsor_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_niveaux_sponsor_id ON public.niveaux_sponsor USING btree (id);


--
-- Name: ix_orders_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_orders_id ON public.orders USING btree (id);


--
-- Name: ix_orders_payment_reference; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE UNIQUE INDEX ix_orders_payment_reference ON public.orders USING btree (payment_reference);


--
-- Name: ix_orders_ticket_category_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_orders_ticket_category_id ON public.orders USING btree (ticket_category_id);


--
-- Name: ix_orders_user_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_orders_user_id ON public.orders USING btree (user_id);


--
-- Name: ix_payments_geniuspay_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE UNIQUE INDEX ix_payments_geniuspay_id ON public.payments USING btree (geniuspay_id);


--
-- Name: ix_payments_geniuspay_reference; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE UNIQUE INDEX ix_payments_geniuspay_reference ON public.payments USING btree (geniuspay_reference);


--
-- Name: ix_payments_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_payments_id ON public.payments USING btree (id);


--
-- Name: ix_payments_order_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_payments_order_id ON public.payments USING btree (order_id);


--
-- Name: ix_rooms_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_rooms_id ON public.rooms USING btree (id);


--
-- Name: ix_sessions_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_sessions_id ON public.sessions USING btree (id);


--
-- Name: ix_sessions_room_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_sessions_room_id ON public.sessions USING btree (room_id);


--
-- Name: ix_sessions_speaker_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_sessions_speaker_id ON public.sessions USING btree (speaker_id);


--
-- Name: ix_speakers_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_speakers_id ON public.speakers USING btree (id);


--
-- Name: ix_sponsors_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_sponsors_id ON public.sponsors USING btree (id);


--
-- Name: ix_sponsors_niveau_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_sponsors_niveau_id ON public.sponsors USING btree (niveau_id);


--
-- Name: ix_ticket_categories_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_ticket_categories_id ON public.ticket_categories USING btree (id);


--
-- Name: ix_tickets_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_tickets_id ON public.tickets USING btree (id);


--
-- Name: ix_tickets_order_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_tickets_order_id ON public.tickets USING btree (order_id);


--
-- Name: ix_tickets_qr_code; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE UNIQUE INDEX ix_tickets_qr_code ON public.tickets USING btree (qr_code);


--
-- Name: ix_translations_entity_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_translations_entity_id ON public.translations USING btree (entity_id);


--
-- Name: ix_translations_entity_type; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_translations_entity_type ON public.translations USING btree (entity_type);


--
-- Name: ix_translations_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_translations_id ON public.translations USING btree (id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: pycon_admin
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: articles articles_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: cfp_submissions cfp_submissions_speaker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.cfp_submissions
    ADD CONSTRAINT cfp_submissions_speaker_id_fkey FOREIGN KEY (speaker_id) REFERENCES public.users(id);


--
-- Name: orders orders_ticket_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_ticket_category_id_fkey FOREIGN KEY (ticket_category_id) REFERENCES public.ticket_categories(id);


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payments payments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: sessions sessions_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: sessions sessions_speaker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_speaker_id_fkey FOREIGN KEY (speaker_id) REFERENCES public.speakers(id);


--
-- Name: speakers speakers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.speakers
    ADD CONSTRAINT speakers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sponsors sponsors_niveau_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.sponsors
    ADD CONSTRAINT sponsors_niveau_id_fkey FOREIGN KEY (niveau_id) REFERENCES public.niveaux_sponsor(id);


--
-- Name: tickets tickets_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pycon_admin
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- PostgreSQL database dump complete
--

\unrestrict jhxMc484mFkBmTH2vseLYcCF5YSEiAWG0MzYBthjI2fbJmCXvAz9LHxkaposfis

